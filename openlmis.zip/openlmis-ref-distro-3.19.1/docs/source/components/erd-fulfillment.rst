===============
Fulfillment ERD
===============

ERD schema of Fulfillment service:

* `Live ERD <http://ci.openlmis.org/erd-fulfillment/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-fulfillment-pipeline/job/master/lastSuccessfulBuild/artifact/erd-fulfillment.zip>`_
