=====================
Stock Management ERD
=====================

ERD schema of Stock Management service:

* `Live ERD <http://ci.openlmis.org/erd-stockmanagement/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-stockmanagement-pipeline/job/master/lastSuccessfulBuild/artifact/erd-stockmanagement.zip>`_
