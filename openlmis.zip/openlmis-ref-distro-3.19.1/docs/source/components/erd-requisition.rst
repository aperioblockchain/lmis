===============
Requisition ERD
===============

ERD schema of Requisition service:

* `Live ERD <http://ci.openlmis.org/erd-requisition/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-requisition-pipeline/job/master/lastSuccessfulBuild/artifact/erd-requisition.zip>`_
