===============
Auth ERD
===============

ERD schema of Auth service:

* `Live ERD <http://ci.openlmis.org/erd-auth/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-auth-pipeline/job/master/lastSuccessfulBuild/artifact/erd-auth.zip>`_
