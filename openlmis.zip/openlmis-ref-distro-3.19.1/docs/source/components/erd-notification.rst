===============
Notification ERD
===============

ERD schema of Notification service:

* `Live ERD <http://ci.openlmis.org/erd-notification/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-notification-pipeline/job/master/lastSuccessfulBuild/artifact/erd-notification.zip>`_
