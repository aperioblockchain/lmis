===================
Reference Data ERD
===================

ERD schema of Reference Data service:

* `Live ERD <http://ci.openlmis.org/erd-referencedata/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-referencedata-pipeline/job/master/lastSuccessfulBuild/artifact/erd-referencedata.zip>`_
