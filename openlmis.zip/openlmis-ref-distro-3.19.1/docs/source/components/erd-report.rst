===============
Report ERD
===============

ERD schema of Report service:

* `Live ERD <http://ci.openlmis.org/erd-report/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-report-pipeline/job/master/lastSuccessfulBuild/artifact/erd-report.zip>`_
