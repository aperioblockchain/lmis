===============
CCE ERD
===============

ERD schema of CCE service:

* `Live ERD <http://ci.openlmis.org/erd-cce/>`_
* `Zip ERD <http://build.openlmis.org/job/OpenLMIS-cce-pipeline/job/master/lastSuccessfulBuild/artifact/erd-cce.zip>`_
