# OpenLMIS Toolbelt

This utility docker image is to hold a number of useful tools while also being small. It is different from [Docker Dev](https://hub.docker.com/r/openlmis/dev) in that it is more lightweight and intended for more than just development.