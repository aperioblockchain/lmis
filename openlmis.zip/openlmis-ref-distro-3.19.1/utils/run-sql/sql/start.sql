-- example sql file, easily replaced by a docker volume mount --
SELECT count(1) from referencedata.users
