# OpenLMIS Debezium Connect

An OpenLMIS version of Debezium's Kafka Connect image. This one includes Confluent's JDBC connector
and Postgres JAR files.
